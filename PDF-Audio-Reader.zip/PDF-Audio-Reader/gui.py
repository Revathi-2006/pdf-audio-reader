import tkinter as tk
from tkinter.filedialog import askopenfilename
from tkinter import messagebox
import threading
import pyttsx3
import PyPDF2

selected_file = ""
is_reading = False

speaker = pyttsx3.init()


def open_pdf():
    global selected_file

    selected_file = askopenfilename(
        filetypes=[("PDF Files", "*.pdf")]
    )

    if selected_file:
        file_label.config(text=f"Selected: {selected_file}")
        status_label.config(text="Status: PDF Selected")


def read_pdf():
    global is_reading

    try:
        pdfreader = PyPDF2.PdfReader(selected_file)

        for page in pdfreader.pages:

            if not is_reading:
                break

            text = page.extract_text()

            if text and text.strip():
                speaker.say(text)
                speaker.runAndWait()

        status_label.config(text="Status: Finished")
        is_reading = False

    except Exception as e:
        messagebox.showerror("Error", str(e))
        status_label.config(text="Status: Error")
        is_reading = False


def start_reading():
    global is_reading

    if not selected_file:
        messagebox.showwarning(
            "No PDF",
            "Please select a PDF first."
        )
        return

    if is_reading:
        return

    is_reading = True
    status_label.config(text="Status: Reading...")

    threading.Thread(target=read_pdf, daemon=True).start()


def stop_reading():
    global is_reading

    is_reading = False
    speaker.stop()

    status_label.config(text="Status: Stopped")


root = tk.Tk()
root.title("PDF Audio Reader")
root.geometry("600x300")


title_label = tk.Label(
    root,
    text="PDF Audio Reader",
    font=("Arial", 16)
)
title_label.pack(pady=10)


file_label = tk.Label(
    root,
    text="Selected: None",
    wraplength=500
)
file_label.pack(pady=10)


open_button = tk.Button(
    root,
    text="Open PDF",
    width=20,
    command=open_pdf
)
open_button.pack(pady=5)


start_button = tk.Button(
    root,
    text="Start Reading",
    width=20,
    command=start_reading
)
start_button.pack(pady=5)


stop_button = tk.Button(
    root,
    text="Stop Reading",
    width=20,
    command=stop_reading
)
stop_button.pack(pady=5)


status_label = tk.Label(
    root,
    text="Status: Ready"
)
status_label.pack(pady=20)


root.mainloop()